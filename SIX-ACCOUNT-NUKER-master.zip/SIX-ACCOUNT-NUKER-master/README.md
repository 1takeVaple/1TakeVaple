# six account nuker || the nuker is back up again!
![Screenshot](screenshot.png)
 
# heads up
     it might say there is a virus, but that's because it's dectecting an exe. just go to downloads in settings and allow it.

      
# UPDATES
    account disabler is broken for now, I'll get it fixed soon.
    updated now it won't be stuck on starting!!
